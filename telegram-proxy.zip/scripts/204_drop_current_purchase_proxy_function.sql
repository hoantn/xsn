-- Xóa hàm purchase_proxy_plan hiện tại
DROP FUNCTION IF EXISTS purchase_proxy_plan(UUID, UUID);
