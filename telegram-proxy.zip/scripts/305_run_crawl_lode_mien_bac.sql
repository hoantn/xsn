-- Execute the crawl function to initialize Lode Mien Bac results
SELECT * FROM crawl_and_initialize_lode_mien_bac_results();
