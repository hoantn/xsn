// lib/prisma.ts
// Đây là một file placeholder để khắc phục lỗi triển khai.
// Dự án của bạn đang sử dụng Supabase cho cơ sở dữ liệu, không phải Prisma.
// Nếu bạn có ý định sử dụng Prisma, bạn cần cấu hình nó đúng cách.
// Nếu không, bạn nên xóa bất kỳ import nào của 'prisma' khỏi mã của mình.
const prisma = {} // Placeholder tối thiểu
export default prisma
